"use client";

import { useState, useEffect } from "react";
import { Activity, ShieldCheck, ShieldAlert, RefreshCw, Clock } from "lucide-react";

interface AuditLogItem {
  id: string;
  eventType: string;
  status: string;
  ipHash: string;
  details: string | null;
  timestamp: string;
}

export default function AuditHistoryPage() {
  const [logs, setLogs] = useState<AuditLogItem[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchLogs();
  }, []);

  const fetchLogs = async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/audit");
      if (res.status === 401) {
        window.location.href = "/login?redirect=/audit&reason=audit";
        return;
      }
      if (res.ok) {
        const data = await res.json();
        setLogs(data.logs || []);
      }
    } catch {
      setLogs([]);
    } finally {
      setLoading(false);
    }
  };


  const formatEventType = (type: string) => {
    switch (type) {
      case "AUTH_LOGIN":
        return "User Login";
      case "AUTH_LOGOUT":
        return "User Logout";
      case "AUTH_REGISTER":
        return "Account Registered";
      case "VAULT_UPLOAD":
        return "Encrypted File Upload";
      case "VAULT_DOWNLOAD":
        return "Encrypted File Download";
      case "VAULT_DELETE":
        return "File Deleted";
      case "ACCESS_DENIED":
        return "Unauthorized Access Denied";
      default:
        return type;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 border-b border-cyber-border pb-6">
        <div>
          <div className="flex items-center space-x-2">
            <h1 className="text-3xl font-extrabold text-white tracking-tight">Security Audit History</h1>
            <span className="px-2.5 py-0.5 rounded text-xs font-semibold bg-purple-500/20 text-purple-300 border border-purple-500/30">
              PRIVACY COMPLIANT
            </span>
          </div>
          <p className="text-sm text-gray-400 mt-1">
            Tamper-evident log of security-relevant operations. All records are sanitized; zero passwords, keys, or plaintext are retained.
          </p>
        </div>

        <button
          onClick={fetchLogs}
          disabled={loading}
          className="inline-flex items-center space-x-2 px-3.5 py-2 rounded-lg text-xs font-medium bg-gray-800 text-gray-300 border border-gray-700 hover:bg-gray-700 hover:text-white transition"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? "animate-spin text-purple-400" : ""}`} />
          <span>Refresh Logs</span>
        </button>
      </div>

      <div className="cyber-card p-6 space-y-4">
        {loading ? (
          <div className="py-12 text-center text-sm text-gray-500 animate-pulse">
            Loading security events...
          </div>
        ) : logs.length === 0 ? (
          <div className="py-12 text-center space-y-2 border border-dashed border-gray-800 rounded-lg">
            <Activity className="w-8 h-8 text-gray-600 mx-auto" />
            <p className="text-sm text-gray-400">No security audit records found.</p>
            <p className="text-xs text-gray-600">
              Operations such as uploads, downloads, logins, and access denials will appear here.
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-gray-300">
              <thead className="bg-gray-900/80 text-gray-400 uppercase tracking-wider font-semibold border-b border-cyber-border">
                <tr>
                  <th className="py-3 px-4">Event</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4">Client IP Hash</th>
                  <th className="py-3 px-4">Details</th>
                  <th className="py-3 px-4 text-right">Timestamp</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-800/60 font-mono">
                {logs.map((log) => (
                  <tr key={log.id} className="hover:bg-gray-900/40 transition">
                    <td className="py-3 px-4 font-medium text-white flex items-center space-x-2 font-sans">
                      {log.status === "SUCCESS" ? (
                        <ShieldCheck className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                      ) : (
                        <ShieldAlert className="w-4 h-4 text-red-400 flex-shrink-0" />
                      )}
                      <span>{formatEventType(log.eventType)}</span>
                    </td>
                    <td className="py-3 px-4 font-sans">
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-semibold tracking-wide ${
                          log.status === "SUCCESS"
                            ? "bg-emerald-500/10 text-emerald-300 border border-emerald-500/30"
                            : "bg-red-500/10 text-red-300 border border-red-500/30"
                        }`}
                      >
                        {log.status}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-gray-400">{log.ipHash}</td>
                    <td className="py-3 px-4 text-gray-400 text-[11px] truncate max-w-xs">
                      {log.details || "-"}
                    </td>
                    <td className="py-3 px-4 text-right text-gray-400 font-sans">
                      <div className="inline-flex items-center space-x-1">
                        <Clock className="w-3 h-3 text-gray-500" />
                        <span>{new Date(log.timestamp).toLocaleString()}</span>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
